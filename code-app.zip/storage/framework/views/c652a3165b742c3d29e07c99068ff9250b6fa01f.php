<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Test')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</head>

<body>
    <div class="wrapper container mt-5">
        <div class="content-wrapper">
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
    </div>
</body>

</html><?php /**PATH E:\Projects\246\code-app\resources\views/layout.blade.php ENDPATH**/ ?>