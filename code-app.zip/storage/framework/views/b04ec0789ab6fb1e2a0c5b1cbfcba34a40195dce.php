<div class="form-group row">
    <?php echo e(Form::label('product_name', 'Product Name')); ?>

    <?php echo e(Form::text('product_name', "", \App\Providers\AppServiceProvider::fieldAttr($errors->has('product_name'),['maxlength' => 255]))); ?>

    <?php if($errors->has('product_name')): ?>
    <small class="invalid-feedback"><?php echo e($errors->first('product_name')); ?></small>
    <?php endif; ?>
</div>
<div class="form-group row">
    <?php echo e(Form::label('qty', 'Quantity')); ?>

    <?php echo e(Form::text('qty', "", \App\Providers\AppServiceProvider::fieldAttr($errors->has('qty'),['maxlength' => 10]))); ?>

    <?php if($errors->has('qty')): ?>
    <small class="invalid-feedback"><?php echo e($errors->first('qty')); ?></small>
    <?php endif; ?>
</div>
<div class="form-group row">
    <?php echo e(Form::label('price', 'Price')); ?>

    <?php echo e(Form::text('price', "", \App\Providers\AppServiceProvider::fieldAttr($errors->has('price'),['maxlength' => 10]))); ?>

    <?php if($errors->has('price')): ?>
    <small class="invalid-feedback"><?php echo e($errors->first('price')); ?></small>
    <?php endif; ?>
</div><?php /**PATH E:\Projects\246\code-app\resources\views/products/form.blade.php ENDPATH**/ ?>